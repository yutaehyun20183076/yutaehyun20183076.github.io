#include <stdio.h>
#include <stdlib.h>
 
typedef struct Node {
    int data;
    struct Node * next;
}List;
 
List * head;
 
void InsertNode(int data, int n);
void DeleteNode(int n);
void PrintNodes(void);
 
void InsertNode(int data, int n)
{
    int i;
    List * new_node = (List*)malloc(sizeof(List));
    new_node->data = data;
    new_node->next = NULL;
    if (n == 1)
    {
        new_node->next = head;
        head = new_node;
        return;
    }
    List * temp2 = head;
    for (i = 0; i < n-2; i++) 
    {
        temp2 = temp2->next;
    }
    new_node->next = temp2->next;
    temp2->next = new_node;
}
 
void DeleteNode(int data) {
	List* cur, * del;
	del = head;
	cur = head;
	while (1) {
		if (data == cur->next->data) {
			del = cur->next;
			cur->next = del->next;
			free(del);
			break;
		}
		cur = cur->next;
	}
}

void PrintNodes(void)
{
    List * temp = head;
    
    while (temp != NULL)
    {
        printf(" %d ", temp->data);
        temp = temp->next;
    }
}
 
int main(void)
{
    head = NULL;
 	int command ,num;
 	int i=1,j=0;
	while(1){
		if(j==1)
			break;
		
		printf("1.Insertion\n2.Deletion\n3.Display\n0.Exit\n\nSelect option : ");
		scanf("%d",&command);
		switch(command){
			case 1:
				printf("Element : ");
				scanf("%d",&num);
				InsertNode(num,i);
				i++;
				printf("Succesfully Insert\n");
				break;
			case 2:
				printf("Delete item : ");
				scanf("%d",&num);
				DeleteNode(num);
				break;	
			case 3:
				PrintNodes();
				printf("\n");
				break;
			case 0:
				j++;
				break;
				
		}
	}
		
		
		
}
