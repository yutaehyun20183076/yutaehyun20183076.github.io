#include <stdio.h>
#include <stdlib.h>
 
typedef struct Node {
    int data;
    struct Node * next;
}List;
 
List * head;
 
void InsertNode(int data, int n);
void PrintNodes(void);
 
void InsertNode(int data, int n)
{
    int i;
    List * new_node = (List*)malloc(sizeof(List));
    new_node->data = data;
    new_node->next = NULL;
    if (n == 1)
    {
        new_node->next = head;
        head = new_node;
        return;
    }
    List * temp2 = head;
    for (i = 0; i < n-2; i++) 
    {
        temp2 = temp2->next;
    }
    new_node->next = temp2->next;
    temp2->next = new_node;
}
 
void PrintNodes(void)
{
    List * temp = head;
    
    while (temp != NULL)
    {
        printf(" %d ", temp->data);
        temp = temp->next;
    }
}
 
int main(void)
{
    head = NULL;
 	int num,i,j,k;
	printf("Enter 5 elements in array : ");
	for (i = 1; i <= 5; i++) {
		scanf("%d", &num);
		InsertNode(num, i);
	}
	printf("Stored elements in array : ");
	PrintNodes();
	printf("\nEnter position for enter element : ");
	scanf("%d", &j);
	printf("Enter new element : ");
	scanf("%d", &k);
	InsertNode(k,j);
	printf("Stored elements in array : ");
	PrintNodes();
}
 
