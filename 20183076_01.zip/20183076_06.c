#include <stdio.h>
#include <stdlib.h>
 
typedef struct node{
    int data;
    struct node *next;
}node;
 
typedef struct Stack{
    node *top; 
}Stack;
 
void InitStack(Stack *stack);
int IsEmpty(Stack *stack);
void Push(Stack *stack, int data);
int Pop(Stack *stack);
void Print(Stack *stack);

void InitStack(Stack *stack)
{
    stack->top = NULL;
}
 
int IsEmpty(Stack *stack)
{
    return stack->top == NULL;
}

void Push(Stack *stack, int data)
{
    node *now = (node *)malloc(sizeof(node)); 
    now->data = data;
    now->next = stack->top;   
    stack->top = now;
}

int Pop(Stack *stack)
{
    node *now;
    int re;
    if (IsEmpty(stack))
    {
        return 0;
    }
    now = stack->top;
    re = now->data;
 
    stack->top = now->next;
    free(now);
    return re;
} 

void Print(Stack *stack)
{
	node *now = (node *)malloc(sizeof(node));
    now = stack->top;
    
    while (now != NULL)
    {
        printf(" %d \n", now->data);
        now = now->next;
    }
}

int main(void)
{
    Stack stack;
    InitStack(&stack);
    int command ,num;
 	int i,k;
	int j=0;
 	char a;
	while(1){
		if(j==1)
			break;
		printf("1.push\n2.pop\n3.display\n4.exit\n\nenter you choice : ");
		scanf("%d",&command);
		switch(command){
			case 1:
				for(i=0;i<=1;){
					printf("Enter element in stack : ");
					scanf("%d",&num);
					Push(&stack,num);
					printf("Pushed on element (y/n)");
					scanf(" %c",&a);
					if (a=='y')
						continue;
					else if (a=='n')	
						break;
					else
						break;
				}
				break;
			case 2:
				printf("Deleted data is %d \n",Pop(&stack));
				break;	
			case 3:
				Print(&stack);
				printf("\n");
				break;
			case 4:
				j++;
				break;
				
		}
	}
    return 0;
}

