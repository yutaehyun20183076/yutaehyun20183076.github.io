#include <stdio.h>
#include <string.h>

int main(void) {
	int arr[10];
	int i,j,k;
 
	printf("Enter 5 elements in array : ");
	for (i = 0; i < 5; i++) {
		scanf("%d", &arr[i]);
	}
	printf("Stored elements in array : ");
	for (i = 0; i < 5; i++) {
		printf(" %d ", arr[i]);
	}
	printf("\nEnter position for enter element : ");
	scanf("%d", &j);
	j=j-1;
	printf("Enter new element : ");
	scanf("%d", &k);
	memmove(arr +j+1, arr + j,sizeof(arr)-j+1);
	arr[j] = k;
	printf("Stored elements in array : ");
	for (i = 0; i < 6; i++) {
		printf(" %d ", arr[i]);
	}
}
