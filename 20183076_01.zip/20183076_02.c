#include <stdio.h>
#include <string.h>

int main(void) {
	int arr[10];
	int i,j,k;
 
	printf("Enter elements in array : ");
	for (i = 0; i < 5; i++) {
		scanf("%d", &arr[i]);
	}
	printf("Stored elements in array : ");
	for (i = 0; i < 5; i++) {
		printf(" %d ", arr[i]);
	}
	printf("\nEnter position of element to delete : ");	
	scanf("%d", &j);
	memmove(arr +j-1, arr + j,sizeof(arr)-j+1);
	printf("After deletion elements in array : ");
	for (i = 0; i < 4; i++) {
		printf(" %d ", arr[i]);
	}
}
